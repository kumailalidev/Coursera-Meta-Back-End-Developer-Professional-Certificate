from django.shortcuts import render

# Create your views here for menu.

# Create view for About

# Create view for Menu